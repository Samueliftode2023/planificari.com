<div id='navigation'>
    <div id='meniu-button'>
        <span class="material-symbols-outlined">
        menu
        </span>
    </div>
    <div class='linkuri'>
        <a href=<?php echo "'".$root."main/dashboard/'";?>>
            <span class="material-symbols-outlined">
            dashboard
            </span>
        </a>
        <a href=<?php echo "'".$root."main/meetings/'";?>>
            <span class="material-symbols-outlined">
            edit_calendar
            </span>
        </a>
        <a href=<?php echo "'".$root."main/meetings/print-meeting/'";?>>
            <span class="material-symbols-outlined">
            print
            </span>
        </a>
        <a href=<?php echo "'".$root."main/herald/privilege-herald/'";?>>
            <span class="material-symbols-outlined">
            badge
            </span>
        </a>
        <a href=<?php echo "'".$root."main/herald/edit-herald/'";?>>
            <span class="material-symbols-outlined">
            person_edit
            </span>
        </a>
    </div>
    <div class='setari'>
        <a href=<?php echo "'".$root."main/settings/'";?>>
            <span class="material-symbols-outlined">
            settings
            </span>
        </a>
        <a id=<?php echo "'logout||".$root."'";?> onclick='logOut(this)' href='#'>
            <span class="material-symbols-outlined">
            logout
            </span>
        </a>
    </div>
</div>
<div id='black-top'>

</div>
<div id='navigation-mobile'>
    <a href=<?php echo "'".$root."main/meetings/'";?>>
        <span class="material-symbols-outlined">
            today
        </span>
    </a>
    <a href=<?php echo "'".$root."main/meetings/print-meeting/'";?>>
        <span class="material-symbols-outlined">
            print
        </span>
    </a>
    <a class='mark-dash' href=<?php echo "'".$root."main/dashboard/'";?>>
        <span class="material-symbols-outlined">
            dashboard
        </span>
    </a>
    <a href=<?php echo "'".$root."main/meetings/print-teme/'";?>>
        <span class="material-symbols-outlined">
            description
        </span>
    </a>
    <a href=<?php echo "'".$root."main/settings/'";?>>
        <span class="material-symbols-outlined">
            settings
        </span>
    </a>
</div>
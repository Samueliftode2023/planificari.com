<div id='container'>
    <div class='bara-control'>Pagina principala</div>
    <div class='container-content'>
        <div>
            <div id='viata-crestina' class='meniu-linkuri'>
                <div class='cap-meniu'>
                    <div class='icon-intrunire'>
                        <span class="material-symbols-outlined">
                            today
                        </span>
                    </div>
                    <h3>Intrunirea din timpul saptamanii</h3>
                </div>
                <div class='linkuri-dash'>
                    <a href='../meetings/schedule-meeting/'>Planifica</a>
                    <br>
                    <a href='../meetings/print-meeting/'>Printare caiet</a>
                    <br>
                    <a href='../meetings/print-teme/'>Printare teme</a>
                </div>
            </div>
        </div>
        <div>
            <div id='viata-crestina' class='meniu-linkuri'>
                <div class='cap-meniu'>
                    <div class='icon-intrunire'>
                        <span class="material-symbols-outlined">
                            person
                        </span>
                    </div>
                    <h3>Vestitori</h3>
                </div>
                <div class='linkuri-dash'>
                    <a href='../herald/edit-herald/'>Editeaza</a>
                    <br>
                    <a href='../herald/privilege-herald/'>Privilegii</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
    $root = '../../../'; 
    $type_session = 'important';
    include_once $root.'included/function/php/common.php';
    include_once $root.'included/function/php/create-table.php';
    check_session($type_session, $root, $conectareDB);
?>
<?php
    header('Location:schedule-meeting/');
    exit;
?>
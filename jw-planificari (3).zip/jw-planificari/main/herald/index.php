<?php
    header('Location:privilege-herald/');
    exit;
?>